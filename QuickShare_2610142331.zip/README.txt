RHILEA FINLAYSON — DANCER WEBSITE
==================================

FILES
- index.html: your responsive one-page website.

BEFORE YOU PUBLISH
1. Open index.html in a browser to preview it.
2. Search for YOUR-EMAIL@example.com and replace it with Rhilea's booking email.
3. Change the Instagram and Facebook links to Rhilea's actual profiles.
4. Replace the sample image URLs with your own approved dance/costume/workshop photos for a more personal site.
5. Review all wording and photo permissions before publishing.

FREE PUBLISHING OPTION: GITHUB PAGES
1. Create or sign in to a free account at https://github.com/
2. Create a new public repository, for example: rhilea-dancer-website
3. Upload index.html to the top level of that repository.
4. Open the repository's Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select the main branch and / (root), then Save.
7. After publishing, GitHub will show your website URL, usually:
   https://YOUR-USERNAME.github.io/rhilea-dancer-website/

It may take a few minutes for the site to appear. GitHub Pages is free for public repositories, but the site URL includes your GitHub username and repository name. You do not need to buy a domain.

ALTERNATIVE: NETLIFY DROP
You can also use https://app.netlify.com/drop if available on your account: drag a folder containing index.html into the upload area and follow the prompts. Check Netlify's current free-plan terms before publishing.

NOTE
This is a static website. The email link opens the visitor's email app; it does not store or process enquiries on the website. Add a form service later only if you want a website enquiry form.
